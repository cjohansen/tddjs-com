/*jslint indent: 2*/
function adder(base) {
  return function (num) {
    return base + num;
  };
}
